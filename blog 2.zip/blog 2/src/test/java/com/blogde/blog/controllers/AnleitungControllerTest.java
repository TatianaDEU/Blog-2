package com.blogde.blog.controllers;

import static org.junit.jupiter.api.Assertions.*;

class AnleitungControllerTest {

}